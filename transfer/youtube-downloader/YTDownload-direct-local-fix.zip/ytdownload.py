"""
YT Download — Portable YouTube Video Downloader
Double-click to run. Auto-updates yt-dlp. Opens browser.
"""

import os
import sys
import uuid
import tempfile
import re
import time
import webbrowser
import threading
import subprocess
from flask import Flask, request, jsonify, send_file, render_template_string
from flask_cors import CORS
import yt_dlp

app = Flask(__name__)
CORS(app)
UPLOAD_DIR = tempfile.mkdtemp()
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024
UPDATE_STATUS = {"checked": False, "result": ""}


# ─── Direct local connection ─────────────────────────────────

# This build intentionally uses the user's local residential IP directly.
# No cookies, browser cookie extraction, static cookie files, proxies, or remote
# EWS/AWS server path. If YouTube anti-bot issues return, discuss a fresh
# strategy before adding auth/proxy behavior back.

# ─── Anti-detection ────────────────────────────────────────────

# Track last download time for rate limiting
_last_download = {'time': 0}
DOWNLOAD_DELAY = 5  # seconds between downloads

def base_opts():
    """Common yt-dlp options. Lets yt-dlp manage per-client UA/headers."""
    opts = {
        'quiet': True,
        'no_warnings': True,
        'noplaylist': True,
        'socket_timeout': 30,
        'extractor_args': {'youtube': {
            # Use multiple clients - yt-dlp merges formats from all of them.
            # Avoid 'web' alone (currently restricted to 360p by YouTube).
            # tv + web_safari + android_vr give the best high-quality coverage.
            'player_client': ['tv', 'web_safari', 'android_vr'],
        }},
    }
    if FFMPEG_DIR:
        opts['ffmpeg_location'] = FFMPEG_DIR
    return opts

def rate_limit():
    """Wait if downloading too fast."""
    elapsed = time.time() - _last_download['time']
    if elapsed < DOWNLOAD_DELAY and _last_download['time'] > 0:
        wait = DOWNLOAD_DELAY - elapsed
        print(f"  Rate limiting: waiting {wait:.1f}s...")
        time.sleep(wait)
    _last_download['time'] = time.time()


# ─── Auto-updater ─────────────────────────────────────────────

def auto_update_ytdlp():
    """Update yt-dlp on startup in background. Only works in non-frozen mode."""
    if getattr(sys, 'frozen', False):
        # Can't pip install inside a frozen exe
        UPDATE_STATUS["result"] = "Bundled version"
        UPDATE_STATUS["checked"] = True
        return
    try:
        result = subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '--upgrade', 'yt-dlp'],
            capture_output=True, text=True, timeout=60
        )
        if 'Successfully installed' in result.stdout:
            ver = result.stdout.strip().split('yt-dlp-')[-1] if 'yt-dlp-' in result.stdout else 'latest'
            UPDATE_STATUS["result"] = f"Updated to {ver}"
        else:
            UPDATE_STATUS["result"] = "Already up to date"
    except Exception as e:
        UPDATE_STATUS["result"] = f"Update check failed: {e}"
    UPDATE_STATUS["checked"] = True


# ─── ffmpeg finder ─────────────────────────────────────────────

def find_ffmpeg():
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(sys.executable)
        if os.path.exists(os.path.join(exe_dir, 'ffmpeg.exe')):
            return exe_dir
        if os.path.exists(os.path.join(sys._MEIPASS, 'ffmpeg.exe')):
            return sys._MEIPASS
    return None

FFMPEG_DIR = find_ffmpeg()


# ─── Frontend ──────────────────────────────────────────────────

FRONTEND = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>YT Download</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root {
    --bg: #f5f5f7;
    --surface: #ffffff;
    --surface-alt: #fafafa;
    --text-1: #1d1d1f;
    --text-2: #6e6e73;
    --text-3: #aeaeb2;
    --blue: #0071e3;
    --blue-hover: #0077ed;
    --blue-light: rgba(0, 113, 227, 0.06);
    --blue-glow: rgba(0, 113, 227, 0.12);
    --green: #34c759;
    --red: #ff3b30;
    --red-light: rgba(255, 59, 48, 0.06);
    --border: rgba(0, 0, 0, 0.06);
    --border-hover: rgba(0, 0, 0, 0.12);
    --shadow-s: 0 1px 2px rgba(0,0,0,0.04);
    --shadow-m: 0 2px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
    --shadow-l: 0 8px 30px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04);
    --radius: 20px;
    --radius-s: 12px;
    --radius-xs: 8px;
    --ease: cubic-bezier(0.25, 0.46, 0.45, 0.94);
    --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
}

body {
    font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: var(--bg);
    color: var(--text-1);
    min-height: 100vh;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

/* ── Nav ─────────────────────────────────────── */
nav {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 100;
    background: rgba(245, 245, 247, 0.72);
    backdrop-filter: saturate(180%) blur(20px);
    -webkit-backdrop-filter: saturate(180%) blur(20px);
    border-bottom: 1px solid var(--border);
}

.nav-inner {
    max-width: 720px;
    margin: 0 auto;
    padding: 0 24px;
    height: 52px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.nav-brand {
    font-size: 17px;
    font-weight: 700;
    letter-spacing: -0.4px;
    color: var(--text-1);
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 8px;
}

.nav-brand svg { flex-shrink: 0; }

.nav-tag {
    font-size: 11px;
    font-weight: 600;
    color: var(--blue);
    background: var(--blue-light);
    padding: 3px 8px;
    border-radius: 6px;
    letter-spacing: 0.3px;
}

.nav-status {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    font-weight: 500;
    color: var(--text-3);
}

.nav-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--text-3);
    transition: background 0.6s;
}

.nav-dot.on { background: var(--green); }

/* ── Hero ────────────────────────────────────── */
.hero {
    padding: 108px 24px 32px;
    text-align: center;
    animation: fadeDown 0.6s var(--ease) both;
}

@keyframes fadeDown {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.hero h1 {
    font-size: clamp(32px, 5.5vw, 44px);
    font-weight: 700;
    letter-spacing: -1.2px;
    line-height: 1.1;
    color: var(--text-1);
    margin-bottom: 8px;
}

.hero p {
    font-size: 16px;
    color: var(--text-2);
    line-height: 1.5;
    max-width: 380px;
    margin: 0 auto;
}

/* ── Main Card ───────────────────────────────── */
.container {
    max-width: 580px;
    margin: 0 auto;
    padding: 0 24px 60px;
}

.card {
    background: var(--surface);
    border-radius: var(--radius);
    box-shadow: var(--shadow-m);
    border: 1px solid var(--border);
    animation: fadeUp 0.5s var(--ease) 0.15s both;
}

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(14px); }
    to { opacity: 1; transform: translateY(0); }
}

.card-inner { padding: 28px; }

/* ── Step Header ─────────────────────────────── */
.step-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
}

.step-num {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: var(--blue);
    color: #fff;
    font-size: 13px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.step-label {
    font-size: 15px;
    font-weight: 600;
    color: var(--text-1);
    letter-spacing: -0.2px;
}

/* ── URL Input ───────────────────────────────── */
.input-row {
    display: flex;
    gap: 8px;
}

.url-input {
    flex: 1;
    height: 46px;
    padding: 0 16px;
    font-size: 14px;
    font-family: inherit;
    font-weight: 450;
    color: var(--text-1);
    background: var(--bg);
    border: 1.5px solid var(--border);
    border-radius: var(--radius-s);
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.url-input::placeholder { color: var(--text-3); }

.url-input:focus {
    border-color: var(--blue);
    box-shadow: 0 0 0 3px var(--blue-glow);
}

.btn-fetch {
    height: 46px;
    padding: 0 20px;
    font-size: 14px;
    font-weight: 600;
    font-family: inherit;
    color: #fff;
    background: var(--blue);
    border: none;
    border-radius: var(--radius-s);
    cursor: pointer;
    transition: background 0.2s, transform 0.15s var(--ease-spring);
    display: flex;
    align-items: center;
    gap: 6px;
    white-space: nowrap;
}

.btn-fetch:hover { background: var(--blue-hover); }
.btn-fetch:active { transform: scale(0.97); }
.btn-fetch:disabled { opacity: 0.45; cursor: default; transform: none; }

.spin {
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin 0.65s linear infinite;
    display: none;
}

@keyframes spin { to { transform: rotate(360deg); } }

/* ── Error ───────────────────────────────────── */
.err {
    display: none;
    margin-top: 14px;
    padding: 10px 14px;
    font-size: 13px;
    font-weight: 500;
    color: var(--red);
    background: var(--red-light);
    border: 1px solid rgba(255,59,48,0.1);
    border-radius: var(--radius-xs);
}

.err.show { display: block; animation: fadeUp 0.3s var(--ease); }

/* ── Divider ─────────────────────────────────── */
.divider {
    height: 1px;
    background: var(--border);
    margin: 24px 0;
}

/* ── Preview ─────────────────────────────────── */
.preview {
    display: none;
    animation: fadeUp 0.4s var(--ease);
}

.preview.show { display: block; }

.thumb-row {
    display: flex;
    gap: 14px;
    padding: 14px;
    background: var(--bg);
    border-radius: var(--radius-s);
    border: 1px solid var(--border);
}

.thumb-img {
    width: 148px;
    min-width: 148px;
    height: 84px;
    border-radius: var(--radius-xs);
    object-fit: cover;
    background: #e8e8ed;
}

.thumb-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 4px;
    min-width: 0;
}

.thumb-title {
    font-size: 13px;
    font-weight: 600;
    line-height: 1.3;
    color: var(--text-1);
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.thumb-meta {
    font-size: 11.5px;
    color: var(--text-2);
    display: flex;
    flex-wrap: wrap;
    gap: 2px 0;
}

.thumb-meta span + span::before {
    content: '\2009\00b7\2009';
    color: var(--text-3);
}

/* ── Quality ─────────────────────────────────── */
.quality-row {
    margin-top: 18px;
}

.quality-title {
    font-size: 12px;
    font-weight: 600;
    color: var(--text-2);
    text-transform: uppercase;
    letter-spacing: 0.6px;
    margin-bottom: 10px;
}

.quality-chips {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}

.chip {
    padding: 7px 16px;
    font-size: 13px;
    font-weight: 500;
    font-family: inherit;
    color: var(--text-2);
    background: var(--surface);
    border: 1.5px solid var(--border);
    border-radius: 100px;
    cursor: pointer;
    transition: all 0.2s var(--ease);
}

.chip:hover {
    border-color: var(--blue);
    color: var(--blue);
}

.chip.on {
    background: var(--blue);
    color: #fff;
    border-color: var(--blue);
}

.chip .sub {
    font-size: 10.5px;
    opacity: 0.65;
    margin-left: 3px;
}

/* ── Download Button ─────────────────────────── */
.dl-wrap { margin-top: 22px; }

.btn-dl {
    width: 100%;
    height: 50px;
    font-size: 15px;
    font-weight: 600;
    font-family: inherit;
    letter-spacing: -0.1px;
    color: #fff;
    background: var(--blue);
    border: none;
    border-radius: var(--radius-s);
    cursor: pointer;
    transition: background 0.2s, transform 0.15s var(--ease-spring), box-shadow 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.btn-dl:hover {
    background: var(--blue-hover);
    box-shadow: 0 4px 16px rgba(0, 113, 227, 0.2);
}

.btn-dl:active { transform: scale(0.985); }
.btn-dl:disabled { opacity: 0.45; cursor: default; transform: none; box-shadow: none; }
.btn-dl .spin { width: 18px; height: 18px; }

/* ── Progress ────────────────────────────────── */
.progress {
    display: none;
    margin-top: 14px;
    animation: fadeUp 0.3s var(--ease);
}

.progress.show { display: block; }

.prog-track {
    height: 4px;
    background: var(--bg);
    border-radius: 2px;
    overflow: hidden;
}

.prog-fill {
    height: 100%;
    background: var(--blue);
    border-radius: 2px;
    animation: ind 2s ease-in-out infinite;
}

@keyframes ind {
    0% { width: 5%; margin-left: 0; }
    50% { width: 40%; margin-left: 35%; }
    100% { width: 5%; margin-left: 95%; }
}

.prog-text {
    font-size: 12px;
    color: var(--text-2);
    text-align: center;
    margin-top: 10px;
}

/* ── Success ─────────────────────────────────── */
.done {
    display: none;
    text-align: center;
    padding: 24px 0 4px;
    animation: fadeUp 0.45s var(--ease);
}

.done.show { display: block; }

.done-icon {
    width: 44px;
    height: 44px;
    margin: 0 auto 14px;
    background: var(--green);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: popIn 0.4s var(--ease-spring);
}

@keyframes popIn {
    0% { transform: scale(0); opacity: 0; }
    100% { transform: scale(1); opacity: 1; }
}

.done-icon svg {
    width: 22px;
    height: 22px;
    stroke: #fff;
    fill: none;
    stroke-width: 3;
    stroke-linecap: round;
    stroke-linejoin: round;
}

.done h3 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 4px;
}

.done-file {
    font-size: 12.5px;
    color: var(--text-2);
    word-break: break-all;
}

.btn-again {
    margin-top: 18px;
    padding: 9px 22px;
    font-size: 13px;
    font-weight: 600;
    font-family: inherit;
    color: var(--blue);
    background: var(--blue-light);
    border: none;
    border-radius: 100px;
    cursor: pointer;
    transition: background 0.2s;
}

.btn-again:hover { background: var(--blue-glow); }

/* ── Footer ──────────────────────────────────── */
.footer {
    text-align: center;
    padding: 20px 24px;
    font-size: 11.5px;
    color: var(--text-3);
    letter-spacing: 0.1px;
}

.footer a {
    color: var(--text-2);
    text-decoration: none;
}

.footer a:hover { text-decoration: underline; }

/* ── Responsive ──────────────────────────────── */
@media (max-width: 520px) {
    .card-inner { padding: 22px 18px; }
    .input-row { flex-direction: column; }
    .btn-fetch { width: 100%; justify-content: center; }
    .thumb-row { flex-direction: column; }
    .thumb-img { width: 100%; height: auto; aspect-ratio: 16/9; min-width: unset; }
    .hero h1 { font-size: 30px; }
}
</style>
</head>
<body>

<nav>
    <div class="nav-inner">
        <a href="#" class="nav-brand">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ff2d55" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            YT Download
        </a>
        <div class="nav-status">
            <div class="nav-dot" id="dot"></div>
            <span id="stat">Starting&hellip;</span>
        </div>
    </div>
</nav>

<section class="hero">
    <h1>Download Video</h1>
    <p>Paste a YouTube link, pick your quality, and download.</p>
</section>

<div class="container">
    <div class="card">
        <div class="card-inner">

            <!-- Step 1: URL -->
            <div class="step-header">
                <div class="step-num">1</div>
                <div class="step-label">Paste Link</div>
            </div>
            <div class="input-row">
                <input type="url" class="url-input" id="url" placeholder="https://youtube.com/watch?v=..." spellcheck="false" autocomplete="off"/>
                <button class="btn-fetch" id="goFetch">
                    <span id="fetchTxt">Fetch</span>
                    <div class="spin" id="fetchSpin"></div>
                </button>
            </div>
            <div class="err" id="err"></div>

            <!-- Step 2: Preview + Quality -->
            <div class="preview" id="prev">
                <div class="divider"></div>
                <div class="step-header">
                    <div class="step-num">2</div>
                    <div class="step-label">Choose Quality</div>
                </div>

                <div class="thumb-row">
                    <img class="thumb-img" id="img" src="" alt=""/>
                    <div class="thumb-info">
                        <div class="thumb-title" id="ttl"></div>
                        <div class="thumb-meta">
                            <span id="who"></span>
                            <span id="dur"></span>
                            <span id="views"></span>
                        </div>
                    </div>
                </div>

                <div class="quality-row">
                    <div class="quality-title">Quality</div>
                    <div class="quality-chips" id="chips"></div>
                </div>

                <div class="divider"></div>

                <!-- Step 3: Download -->
                <div class="step-header">
                    <div class="step-num">3</div>
                    <div class="step-label">Download</div>
                </div>

                <div class="dl-wrap">
                    <button class="btn-dl" id="dlBtn">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                            <polyline points="7 10 12 15 17 10"/>
                            <line x1="12" y1="15" x2="12" y2="3"/>
                        </svg>
                        <span id="dlTxt">Download MP4</span>
                        <div class="spin" id="dlSpin"></div>
                    </button>
                </div>

                <div class="progress" id="prog">
                    <div class="prog-track"><div class="prog-fill"></div></div>
                    <div class="prog-text" id="progTxt">Downloading&hellip;</div>
                </div>
            </div>

            <!-- Success -->
            <div class="done" id="done">
                <div class="done-icon">
                    <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <h3>Download Complete</h3>
                <div class="done-file" id="doneFile"></div>
                <button class="btn-again" id="again">Download Another</button>
            </div>

        </div>
    </div>
    <div class="footer">Powered by <a href="https://github.com/yt-dlp/yt-dlp" target="_blank">yt-dlp</a> &amp; FFmpeg</div>
</div>

<script>
const X='',E=id=>document.getElementById(id);
let Q='best';

E('dot').classList.add('on');
E('stat').textContent='Ready';
fetch(X+'/api/config').then(r=>r.json()).then(d=>{
    E('stat').textContent=d.connection==='direct'?'Ready (direct)':'Ready';
}).catch(()=>{});

function sE(m){E('err').textContent=m;E('err').classList.add('show')}
function hE(){E('err').classList.remove('show')}
function fD(s){if(!s)return'';const m=Math.floor(s/60),x=s%60;return m>59?Math.floor(m/60)+'h '+m%60+'m':m+':'+String(x).padStart(2,'0')}
function fV(n){if(!n)return'';return n>=1e6?(n/1e6).toFixed(1)+'M views':n>=1e3?(n/1e3).toFixed(0)+'K views':n+' views'}
function fB(b){if(!b)return'';return b>=1e9?'~'+(b/1e9).toFixed(1)+' GB':b>=1e6?'~'+(b/1e6).toFixed(0)+' MB':'~'+(b/1e3).toFixed(0)+' KB'}

async function doFetch(){
    const u=E('url').value.trim();if(!u)return;
    hE();E('prev').classList.remove('show');E('done').classList.remove('show');
    E('goFetch').disabled=1;E('fetchSpin').style.display='block';E('fetchTxt').textContent='';
    try{
        const r=await fetch(X+'/api/info',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:u})});
        const d=await r.json();if(!r.ok)throw new Error(d.error||'Failed');
        E('img').src=d.thumbnail;E('ttl').textContent=d.title;
        E('who').textContent=d.uploader;E('dur').textContent=fD(d.duration);E('views').textContent=fV(d.view_count);
        const c=E('chips');c.innerHTML='';
        const mk=(l,v,sel)=>{const b=document.createElement('button');b.className='chip'+(sel?' on':'');b.innerHTML=l;b.onclick=()=>{Q=v;c.querySelectorAll('.chip').forEach(x=>x.classList.remove('on'));b.classList.add('on')};c.appendChild(b)};
        mk('Best','best',true);
        (d.formats||[]).forEach(f=>mk(f.label+(f.filesize?'<span class="sub">'+fB(f.filesize)+'</span>':''),String(f.height),false));
        Q='best';E('prev').classList.add('show');
    }catch(e){sE(e.message)}
    finally{E('goFetch').disabled=0;E('fetchSpin').style.display='none';E('fetchTxt').textContent='Fetch'}
}

async function doDl(){
    const u=E('url').value.trim();if(!u)return;hE();
    E('dlBtn').disabled=1;E('dlSpin').style.display='block';E('dlTxt').textContent='Downloading\u2026';
    E('prog').classList.add('show');E('progTxt').textContent='Downloading and processing\u2026';
    try{
        const r=await fetch(X+'/api/download',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:u,quality:Q})});
        if(!r.ok){const e=await r.json();throw new Error(e.error||'Failed')}
        E('progTxt').textContent='Saving\u2026';
        const bl=await r.blob();let fn='video.mp4';
        const cd=r.headers.get('Content-Disposition');
        if(cd){const m=cd.match(/filename\*?=(?:UTF-8''|"?)([^";]+)/i);if(m)fn=decodeURIComponent(m[1].replace(/"/g,''))}
        const a=document.createElement('a');a.href=URL.createObjectURL(bl);a.download=fn;
        document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(a.href);
        E('prog').classList.remove('show');E('prev').classList.remove('show');
        E('doneFile').textContent=fn;E('done').classList.add('show');
    }catch(e){sE(e.message);E('prog').classList.remove('show')}
    finally{E('dlBtn').disabled=0;E('dlSpin').style.display='none';E('dlTxt').textContent='Download MP4'}
}

function reset(){E('url').value='';Q='best';E('prev').classList.remove('show');E('done').classList.remove('show');hE();E('url').focus()}

E('goFetch').addEventListener('click',doFetch);
E('dlBtn').addEventListener('click',doDl);
E('again').addEventListener('click',reset);
E('url').addEventListener('keypress',e=>{if(e.key==='Enter')doFetch()});
</script>
</body>
</html>"""


# ─── Routes ───────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template_string(FRONTEND)

@app.route('/api/config')
def config():
    return jsonify({
        "status": "ready",
        "app": "YTDownload",
        "connection": "direct",
        "update": UPDATE_STATUS,
        "proxy": {"active": False, "count": 0},
        "cookies": False
    })

@app.route('/api/info', methods=['POST'])
def yt_info():
    data = request.get_json()
    url = data.get('url', '').strip()
    if not url:
        return jsonify({"error": "No URL provided"}), 400
    if not re.match(r'https?://(www\.)?(youtube\.com|youtu\.be)/', url):
        return jsonify({"error": "Invalid YouTube URL"}), 400
    try:
        opts = base_opts()
        opts['skip_download'] = True
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
        formats, seen = [], set()
        for f in info.get('formats', []):
            h = f.get('height')
            if f.get('vcodec', 'none') == 'none' or not h:
                continue
            label = f"{h}p"
            if label not in seen:
                seen.add(label)
                formats.append({"label": label, "height": h, "filesize": f.get('filesize') or f.get('filesize_approx') or 0, "has_audio": f.get('acodec', 'none') != 'none'})
        formats.sort(key=lambda x: x['height'], reverse=True)
        return jsonify({"title": info.get('title', 'Unknown'), "duration": info.get('duration', 0), "thumbnail": info.get('thumbnail', ''), "uploader": info.get('uploader', 'Unknown'), "view_count": info.get('view_count', 0), "formats": formats[:6]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/download', methods=['POST'])
def yt_download():
    data = request.get_json()
    url = data.get('url', '').strip()
    quality = data.get('quality', 'best')
    if not url:
        return jsonify({"error": "No URL provided"}), 400
    if not re.match(r'https?://(www\.)?(youtube\.com|youtu\.be)/', url):
        return jsonify({"error": "Invalid YouTube URL"}), 400
    job_id = str(uuid.uuid4())[:8]
    outtmpl = os.path.join(UPLOAD_DIR, f"{job_id}_%(title)s.%(ext)s")
    try:
        rate_limit()
        
        # Format fallback chain - progressively simpler if YouTube restricts
        if quality == 'best':
            format_chain = [
                'bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best',
                'bestvideo+bestaudio/best',
                'best[ext=mp4]/best',
                'best',
                'worstvideo+worstaudio/worst',  # last resort: get anything
            ]
        else:
            format_chain = [
                f'bestvideo[height<={quality}][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<={quality}]+bestaudio/best[height<={quality}]',
                f'bestvideo[height<={quality}]+bestaudio/best[height<={quality}]/best',
                'best[ext=mp4]/best',
                'best',
            ]
        
        last_err = None
        for fmt in format_chain:
            try:
                opts = base_opts()
                opts.update({
                    'format': fmt,
                    'merge_output_format': 'mp4',
                    'outtmpl': outtmpl,
                    'noprogress': True,
                    'postprocessors': [{
                        'key': 'FFmpegVideoConvertor',
                        'preferedformat': 'mp4',
                    }],
                    'postprocessor_args': {
                        'default': ['-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k'],
                    },
                })
                with yt_dlp.YoutubeDL(opts) as ydl:
                    ydl.download([url])
                last_err = None
                break  # success
            except Exception as e:
                last_err = e
                err_str = str(e).lower()
                if 'requested format' in err_str or 'no video formats' in err_str:
                    print(f"  Format '{fmt[:40]}...' unavailable, trying next...")
                    continue
                else:
                    raise  # non-format error, don't retry
        
        if last_err:
            raise last_err
        
        output_file = None
        for f in os.listdir(UPLOAD_DIR):
            if f.startswith(job_id):
                output_file = os.path.join(UPLOAD_DIR, f)
                break
        if not output_file or not os.path.exists(output_file):
            return jsonify({"error": "File not found after download."}), 500
        filename = os.path.basename(output_file).replace(f"{job_id}_", "")
        return send_file(output_file, as_attachment=True, download_name=filename, mimetype='video/mp4')
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.before_request
def cleanup():
    now = time.time()
    try:
        for f in os.listdir(UPLOAD_DIR):
            fp = os.path.join(UPLOAD_DIR, f)
            if os.path.isfile(fp) and now - os.path.getmtime(fp) > 600:
                os.remove(fp)
    except:
        pass

def is_port_in_use(port):
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) == 0

def is_ytdownload_running(port):
    """Return True only if the existing service looks like this app."""
    try:
        import urllib.request
        import json as _json
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/config', timeout=1) as r:
            data = _json.loads(r.read().decode('utf-8'))
        return data.get('app') == 'YTDownload'
    except Exception:
        return False

def find_port(start=5000, max_tries=20):
    """Use 5000 if available; otherwise find the next free localhost port."""
    for port in range(start, start + max_tries):
        if not is_port_in_use(port):
            return port
    raise RuntimeError(f"No free port found from {start} to {start + max_tries - 1}")

def open_browser(port):
    """Open browser only after the local server is actually responding."""
    import urllib.request
    url = f'http://127.0.0.1:{port}'
    for _ in range(80):  # ~20 seconds
        try:
            with urllib.request.urlopen(f'{url}/api/config', timeout=0.5) as r:
                if r.status == 200:
                    webbrowser.open(url)
                    return
        except Exception:
            time.sleep(0.25)
    # Last-resort open so the console does not appear dead.
    webbrowser.open(url)

if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()

    # If this app is already running, just open browser and exit. If another
    # app owns 5000, use the next free port instead of opening the wrong page.
    if is_ytdownload_running(5000):
        webbrowser.open('http://127.0.0.1:5000')
        sys.exit(0)

    port = find_port(5000)

    print()
    print("  YT Download")
    print("  ============")
    print(f"  http://127.0.0.1:{port}")
    print("  Connection: direct residential IP (no cookies/proxies)")
    print("  Close this window to quit.")
    print()

    try:
        # Auto-update yt-dlp in background
        threading.Thread(target=auto_update_ytdlp, daemon=True).start()

        # Open browser once server is ready
        threading.Thread(target=open_browser, args=(port,), daemon=True).start()

        app.run(host='127.0.0.1', port=port, debug=False, use_reloader=False)
    except Exception as e:
        print(f"\n  ERROR: {e}")
        input("\n  Press Enter to close...")
