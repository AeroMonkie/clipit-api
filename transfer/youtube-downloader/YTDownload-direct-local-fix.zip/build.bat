@echo off
setlocal
echo.
echo   ====================================
echo    YT Download - Build Portable .exe
echo   ====================================
echo.

:: Step 1 - Install build tools
echo   [1/5] Installing dependencies...
python -m pip install --upgrade pyinstaller flask flask-cors yt-dlp --user -q 2>nul
if %errorlevel% neq 0 (
    python -m pip install --upgrade pyinstaller flask flask-cors yt-dlp -q
)

:: Step 2 - Download ffmpeg if not present
echo   [2/5] Checking ffmpeg...
if exist "ffmpeg.exe" (
    echo          Found ffmpeg.exe
) else (
    echo          Downloading ffmpeg...
    python -c "import urllib.request,zipfile,os,shutil;print('          Fetching...');urllib.request.urlretrieve('https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip','ff.zip');print('          Extracting...');z=zipfile.ZipFile('ff.zip');[z.extract(f) for f in z.namelist() if f.endswith('ffmpeg.exe')];z.close();os.remove('ff.zip');[shutil.move(os.path.join(r,f),'ffmpeg.exe') for r,d,files in os.walk('.') for f in files if f=='ffmpeg.exe' and r!='.']"
    if exist "ffmpeg.exe" (
        echo          Done.
    ) else (
        echo          ERROR: ffmpeg download failed.
        pause
        exit /b 1
    )
)
for /d %%D in (ffmpeg-*) do rd /s /q "%%D" 2>nul

:: Step 3 - Clean old builds and leftover temp
echo   [3/5] Cleaning old builds...
if exist "dist" rd /s /q dist
if exist "build" rd /s /q build
if exist "YTDownload.spec" del YTDownload.spec
for /d %%D in ("%TEMP%\_MEI*") do rd /s /q "%%D" 2>nul

:: Step 4 - Build
echo   [4/5] Building .exe (this takes a few minutes)...
python -m PyInstaller ^
    --onefile ^
    --name "YTDownload" ^
    --collect-all yt_dlp ^
    --hidden-import flask ^
    --hidden-import flask_cors ^
    --hidden-import yt_dlp ^
    --hidden-import jinja2 ^
    --hidden-import markupsafe ^
    --add-data "ffmpeg.exe;." ^
    --icon "icon.ico" ^
    ytdownload.py

if %errorlevel% neq 0 (
    echo.
    echo   BUILD FAILED. Check output above.
    pause
    exit /b 1
)

:: Step 5 - Package
echo   [5/5] Packaging...
if not exist "release" mkdir release
copy /y "dist\YTDownload.exe" "release\YTDownload.exe" >nul

echo.
echo   ====================================
echo    BUILD COMPLETE
echo.
echo    release\YTDownload.exe
echo.
echo    Double-click to run on any PC.
echo    No installation needed.
echo   ====================================
echo.
explorer "release"
pause
