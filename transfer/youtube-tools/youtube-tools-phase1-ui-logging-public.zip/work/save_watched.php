<?php
// Set headers for access
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$filename = 'watched_videos.json';

// Initialize data if file doesn't exist
if (!file_exists($filename)) {
    file_put_contents($filename, json_encode([]));
}

// Read current data
$current_data = json_decode(file_get_contents($filename), true);
if (!is_array($current_data)) {
    $current_data = [];
}

// Handle POST request (Update status)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId = $input['id'] ?? null;
    $isWatched = $input['watched'] ?? false;

    if ($videoId) {
        if ($isWatched) {
            // Add to array if not present
            if (!in_array($videoId, $current_data)) {
                $current_data[] = $videoId;
            }
        } else {
            // Remove from array
            $current_data = array_values(array_diff($current_data, [$videoId]));
        }
        
        // Save back to file
        file_put_contents($filename, json_encode($current_data));
        echo json_encode(['status' => 'success', 'watched' => $isWatched]);
    } else {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'No Video ID provided']);
    }
} 
// Handle GET request (Fetch list)
else {
    echo json_encode(['watched_ids' => $current_data]);
}
?>