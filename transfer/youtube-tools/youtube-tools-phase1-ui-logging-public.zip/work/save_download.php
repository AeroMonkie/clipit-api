<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$filename = 'downloads_log.json';
$allowed = ['acifin', 'creator_shield', 'superbam'];

function default_log() {
    return ['acifin' => [], 'creator_shield' => [], 'superbam' => []];
}

if (!file_exists($filename)) {
    file_put_contents($filename, json_encode(default_log(), JSON_PRETTY_PRINT), LOCK_EX);
}

$data = json_decode(file_get_contents($filename), true);
if (!is_array($data)) {
    $data = default_log();
}
foreach ($allowed as $company) {
    if (!isset($data[$company]) || !is_array($data[$company])) {
        $data[$company] = [];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
        exit;
    }

    $company = $input['company'] ?? '';
    $videoId = trim($input['videoId'] ?? '');
    $title = trim($input['title'] ?? 'Untitled video');
    $url = trim($input['url'] ?? '');

    if (!in_array($company, $allowed, true)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid company']);
        exit;
    }
    if (!preg_match('/^[A-Za-z0-9_-]{6,20}$/', $videoId)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid video ID']);
        exit;
    }
    if ($url === '') {
        $url = 'https://youtu.be/' . $videoId;
    }
    if (!preg_match('#^https://(www\.)?(youtube\.com|youtu\.be)/#', $url)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid YouTube URL']);
        exit;
    }

    $entry = [
        'videoId' => $videoId,
        'title' => substr($title, 0, 250),
        'url' => $url,
        'date' => date('M j, Y'),
        'saved_at' => date('c')
    ];

    $updated = false;
    foreach ($data[$company] as $idx => $existing) {
        if (($existing['videoId'] ?? '') === $videoId) {
            $data[$company][$idx] = $entry;
            $updated = true;
            break;
        }
    }
    if (!$updated) {
        array_unshift($data[$company], $entry);
    }

    file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    echo json_encode(['status' => 'success', 'downloads' => $data]);
    exit;
}

echo json_encode(['downloads' => $data]);
?>
