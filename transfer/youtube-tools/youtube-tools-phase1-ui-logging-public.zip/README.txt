YouTube Tools Phase 1 UI/logging prototype.

Public transfer copy: API_KEY and CLIENT_ID in work/index.html were replaced with placeholders before pushing to GitHub. Reinsert the site's existing YouTube API key and Google OAuth client ID before deploying/testing OAuth/API calls.

Removed from this build per Sam's request:
- Last Access badge
- save_access.php
- last_access.txt
